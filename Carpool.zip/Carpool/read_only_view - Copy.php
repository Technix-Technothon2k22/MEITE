
<div class="box">

	To,<br>
	name<br>
	department<br><br>
	
	Date : application_date<br><br>
	<b><i>
		Subject :Requesting for a vichle from start_date to ending_date<br>
		Pickup Location : pickup_location<br><br>
	</i></b>
	Sir,<br>
	<?=$application_details['message']?><br><br>

	<?=$applicant_name['name']?><br>
	<?=$applicant_details['department']?><br>
	<a href="tel:phone">+91 phone</a><br>
	<a href="mailto:mail_id">mail_id</a><br>

	<br>
	<code class="col-12" readonly>log</code>
</div>
