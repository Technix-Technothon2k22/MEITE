<?php
	if(!include 'config.php'){
		die('<br><br><br>Installation required !!! <br><b>Open <a href="./install.php">install.php</a></b>');
	}
	date_default_timezone_set("Asia/Kolkata");
	define('', true);
	session_name('');
	session_start();
?>