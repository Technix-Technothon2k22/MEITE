<?php
		$email = "sushmariliger@gmail.com";
		$user_pass = "abcdefghijklmno1234";
		$host = "localhost";
		$path = "/";
		$db_name = "sri";
		$db_user = "sri";
		$db_pass = "root";
?>