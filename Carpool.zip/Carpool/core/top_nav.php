<nav class="navbar navbar-dark bg-info" style="background-image: linear-gradient(-45deg, #6078EA, #17EAD9);">
	<a class="navbar-brand" href="<?php echo $_SERVER['REQUEST_SCHEME'].'://'.$host.$path; ?>">	

	<a class="btn btn-primary my-2 my-sm-0" href="logout.php">Logout</a>
</nav>
