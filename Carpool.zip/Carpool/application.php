<?php 
	include 'core/core.inc.php';
	if (!isset($_SESSION['user_id'])) { header("Location: login.php");}
	
	$save_message = false;
	$apply_message = false;

	if(isset($_POST['draft'])) {
	



	
	$servername = "localhost";
$username = "sri";
$password = "root";
$dbname = "sri";

$did=rand(0,4000);

			$srcdate =  $_POST['startDate'];
			$srcTime=$_POST['startTime'];		
			$srcTime = (string)($srcTime);
			$srcTime=str_replace (':', '-', $srcTime);
			$srcName = $_POST['sourceName'];	
			$desName = $_POST['destinationName'];				
			$url=$_POST['drivingRoute'];			
			$url= urlencode($url);
			$url=mysql_real_escape_string($url);			
			$mes = $_POST['message'];				
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO application (draft_id,startDate, startTime, sourceName,destinationName,URL,Comments) VALUES 
  ($did,$srcdate,$srcTime,$srcName,$desName,$url,$mes)";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta name="og:title" property="og:title" content=""/>
	<?php
		include 'core/meta.php';
	?>
	<link rel="stylesheet" href="css/core.css">
	<style type="text/css">
		.paper_form input{
			/*border: 0px;*/
		}
		.paper_form label{
			padding: 0 0 0 15px;
		}
	</style>
</head>
<body>
	<?php
		require "core/top_nav.php";
	?>
	<div class="container-fluid">
		<div class="row">
			<div class="col col-lg-3 side_nav">
				<?php
					$active = "application";
					require "core/side_nav.php";
				?>
			</div>
			<div class="col-md-9">
				<center>
					<h1>Need a Ride</h1>
				</center>
				<br/>
				<form class="paper_form" method="POST">
					<input type="hidden" name="applied" value="<?php if(isset($_GET['draft_id'])){echo $draft_details['applied'];}else{ echo "N";} ?>">
					<div class="form-row" style="visibility: hidden;">
						<div class="form-group col-md-4">
							<?php if (isset($_GET['draft_id'])) { echo $_GET['draft_id'];} ?>
						</div>
					</div>
					<div class="form-row justify-content-between" style="visibility: hidden;">
						<div class="form-group col-md-4">
							<label for="sendingTo">Respected Sir/Madem,</label>
							<select name="to" class="form-control" id="sendingTo" >
								<?php foreach ($admin_list as $key => $value): ?>
									<option <?php if(isset($draft_details['receiver'])) if($draft_details['receiver'] == $value['id']){echo "selected";}?> value="<?=$value['id']?>"><?=$value['name']?> (<?=$value['department']?>)</option>
								<?php endforeach ?>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label> Date: <?php echo date("d M Y", time()); ?></label>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-3">
							<label for="startDate">Starting Date</label>
							<input type="date" name="startDate" class="form-control" id="startDate" value="<?php if(isset($start_date)){ echo $start_date;} ?>">
						</div>
						<div class="form-group col-md-3">
							<label for="startTime">Starting Time</label>
							<input type="time" name="startTime" class="form-control" id="startTime" value="<?php if(isset($start_time)){ echo $start_time;} ?>" >
						</div>
					</div>
					
					<div class="form-row ">
						<div class="form-group col-md-3">
							<label for="SN">Source Name</label>
							<input type="text" name="sourceName" class="form-control" value="<?php if(isset($_GET['draft_id'])){ echo $draft_details['sourceName'];} ?>" id="sourceName" placeholder="Source">
						</div>
						<div class="form-group col-md-3">
							<label for="vehicleType">Destiation Name</label>
							<input type="text" name="destinationName" class="form-control" value="<?php if(isset($_GET['draft_id'])){ echo $draft_details['destinationName'];} ?>" id="destinationName" placeholder="Destination">
						</div>
						<div class="form-group col-md-3">
							<label for="vehicleType">Add Route URL</label>
							<input type="url" name="drivingRoute" class="form-control" value="<?php if(isset($_GET['draft_id'])){ echo $draft_details['drivingRoute'];} ?>" id="drivingRoute" placeholder="url">
							<a href="https://mymaps.google.com" target="_blank"> Create Your Route</a>
						</div>
					</div>
					<div class="form-group">
						<label for="exampleFormControlTextarea1">Describe your requirement</label>
						<textarea class="form-control" name="message" id="message" rows="5"><?php if (isset($_GET['draft_id'])) {
							echo $draft_details['message'];
						} ?></textarea>
					</div>
					<div class="form-check">
						<input class="form-check-input" type="checkbox" name="notify" id="defaultCheck1" <?php if (isset($_GET['draft_id'])) {
							if ($draft_details['notification'] == 'Y') {
								echo "checked";
							}
						}else echo "checked"; ?>>
						<label class="form-check-label" for="defaultCheck1">Receive Notification</label>
					</div>
					<br>
					<button type="submit" name="draft" class="btn btn-primary">Save to Draft</button> &nbsp;&nbsp;&nbsp;
					
					<?php if (isset($_GET['draft_id'])) {
						echo '<button type="submit" name="apply" class="btn btn-primary">Apply</button>';
					} ?>
				</form>
				<br><br>
			</div>
		</div>
	</div>
</body>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/swal.js"></script>
<script type="text/javascript">
	<?php
		if ($save_message) {
			echo 'swal({title:"'.$save_message.'",icon: "success"});';
		}
		if ($apply_message) {
			echo 'swal({title:"'.$apply_message.'",icon: "error"});';
		}
	?>

	function set_application_reciver(id, name) {
		$('#helper').html("");
		$('#sending_to_id').val(id);
		$('#sendingTo').val(name);
	}
	$("#sendingTo").keyup(function (e) {
		$.ajax({
			url: "ajax/get_suggestion.php?q="+this.value,
			dataType: 'JSON',
			success: function(result){
				console.log(result);
				$('#helper').html("");
				for (var i = result.length - 1; i >= 0; i--) {
					console.log(result[i]);

					$('#helper').append('<label style="border: 1px dotted black; width: 100%; cursor: pointer;" onclick="set_application_reciver(\''+result[i]['draft_id']+'\', \''+result[i]['startDate']+'\',\''+result[i]['startTime']+' '+result[i]['sourceName']+' '+result[i]['destinationName']+'\' )">'+result[i]['URL']+' '+result[i]['Comments']+')</label>');
				}
			},
		});
	});
</script>
</html>